using DatingPick.Api.Data;
using DatingPick.Api.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<DatingPickDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("DatingPick")));
builder.Services.AddScoped<IActivityService, ActivityService>();
builder.Services.AddCors(o => o.AddPolicy("DatingPickCors", p =>
    p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("DatingPickCors");
app.UseAuthorization();
app.MapControllers();
app.Run();
