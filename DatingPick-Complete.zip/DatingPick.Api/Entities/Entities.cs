namespace DatingPick.Api.Entities;

public class Couple {
    public Guid CoupleId { get; set; }
    public string Name { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public byte[] RowVersion { get; set; } = [];
    public ICollection<CoupleMember> Members { get; set; } = [];
    public ICollection<Activity> Activities { get; set; } = [];
}
public class CoupleMember {
    public Guid MemberId { get; set; }
    public Guid CoupleId { get; set; }
    public string DisplayName { get; set; } = "";
    public string Role { get; set; } = "";
    public string Icon { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public Couple Couple { get; set; } = null!;
    public ICollection<ActivitySelection> Selections { get; set; } = [];
}
public class Activity {
    public Guid ActivityId { get; set; }
    public Guid CoupleId { get; set; }
    public Guid? OwnerMemberId { get; set; }
    public string ActivityText { get; set; } = "";
    public string Status { get; set; } = "Active";
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public byte[] RowVersion { get; set; } = [];
    public Couple Couple { get; set; } = null!;
    public ICollection<ActivitySelection> Selections { get; set; } = [];
}
public class ActivitySelection {
    public Guid ActivityId { get; set; }
    public Guid MemberId { get; set; }
    public bool IsSelected { get; set; }
    public DateTime UpdatedAtUtc { get; set; }
    public Activity Activity { get; set; } = null!;
    public CoupleMember Member { get; set; } = null!;
}
public class SpinHistory {
    public Guid SpinHistoryId { get; set; }
    public Guid CoupleId { get; set; }
    public Guid? MemberId { get; set; }
    public Guid ActivityId { get; set; }
    public string Mode { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
}
