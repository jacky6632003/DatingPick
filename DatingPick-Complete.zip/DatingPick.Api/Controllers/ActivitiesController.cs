using DatingPick.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DatingPick.Api.Controllers;

[ApiController]
[Route("api/v1/couples/{coupleId:guid}/activities")]
public class ActivitiesController(IActivityService service) : ControllerBase {
    [HttpGet] public async Task<IActionResult> Get(Guid coupleId)=>Ok(await service.List(coupleId));
    [HttpPost] public async Task<IActionResult> Create(Guid coupleId,CreateActivityRequest r)=>Ok(await service.Create(coupleId,r));
    [HttpPut("{activityId:guid}/selection")] public async Task<IActionResult> Select(Guid coupleId,Guid activityId,UpdateSelectionRequest r)=>Ok(await service.Select(coupleId,activityId,r));
    [HttpPost("{activityId:guid}/complete")] public async Task<IActionResult> Complete(Guid coupleId,Guid activityId)=>Ok(await service.Complete(coupleId,activityId));
    [HttpPost("{activityId:guid}/restore")] public async Task<IActionResult> Restore(Guid coupleId,Guid activityId)=>Ok(await service.Restore(coupleId,activityId));
    [HttpDelete("{activityId:guid}")] public async Task<IActionResult> Delete(Guid coupleId,Guid activityId){await service.Delete(coupleId,activityId);return NoContent();}
}
