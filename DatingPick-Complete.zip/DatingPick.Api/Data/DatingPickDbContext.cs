using DatingPick.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace DatingPick.Api.Data;

public class DatingPickDbContext(DbContextOptions<DatingPickDbContext> options) : DbContext(options)
{
    public DbSet<Couple> Couples => Set<Couple>();
    public DbSet<CoupleMember> CoupleMembers => Set<CoupleMember>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<ActivitySelection> ActivitySelections => Set<ActivitySelection>();
    public DbSet<SpinHistory> SpinHistories => Set<SpinHistory>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Couple>().ToTable("Couple").HasKey(x => x.CoupleId);
        b.Entity<Couple>().Property(x => x.RowVersion).IsRowVersion();

        b.Entity<CoupleMember>().ToTable("CoupleMember").HasKey(x => x.MemberId);
        b.Entity<CoupleMember>().HasIndex(x => new { x.CoupleId, x.Role }).IsUnique();
        b.Entity<CoupleMember>().HasOne(x => x.Couple).WithMany(x => x.Members)
            .HasForeignKey(x => x.CoupleId).OnDelete(DeleteBehavior.Cascade);

        b.Entity<Activity>().ToTable("Activity").HasKey(x => x.ActivityId);
        b.Entity<Activity>().Property(x => x.RowVersion).IsRowVersion();
        b.Entity<Activity>().Property(x => x.ActivityText).HasMaxLength(500).IsRequired();
        b.Entity<Activity>().HasOne(x => x.Couple).WithMany(x => x.Activities)
            .HasForeignKey(x => x.CoupleId).OnDelete(DeleteBehavior.Cascade);

        b.Entity<ActivitySelection>().ToTable("ActivitySelection")
            .HasKey(x => new { x.ActivityId, x.MemberId });
        b.Entity<ActivitySelection>().HasOne(x => x.Activity)
            .WithMany(x => x.Selections).HasForeignKey(x => x.ActivityId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<ActivitySelection>().HasOne(x => x.Member)
            .WithMany(x => x.Selections).HasForeignKey(x => x.MemberId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<SpinHistory>().ToTable("SpinHistory").HasKey(x => x.SpinHistoryId);
    }
}
