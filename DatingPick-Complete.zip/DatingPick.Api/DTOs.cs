namespace DatingPick.Api;

public record CreateActivityRequest(string ActivityText, Guid? OwnerMemberId);
public record UpdateSelectionRequest(Guid MemberId, bool IsSelected);
public record SpinRequest(string Mode = "common", Guid? MemberId = null);

public class ActivityResponse {
    public Guid ActivityId { get; set; }
    public Guid CoupleId { get; set; }
    public Guid? OwnerMemberId { get; set; }
    public string ActivityText { get; set; } = "";
    public string Status { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public List<SelectionResponse> Selections { get; set; } = [];
}
public class SelectionResponse {
    public Guid MemberId { get; set; }
    public bool IsSelected { get; set; }
}
