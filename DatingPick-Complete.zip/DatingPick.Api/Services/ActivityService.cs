using DatingPick.Api.Data;
using DatingPick.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace DatingPick.Api.Services;

public interface IActivityService {
    Task<List<ActivityResponse>> List(Guid coupleId);
    Task<ActivityResponse> Create(Guid coupleId, CreateActivityRequest request);
    Task<ActivityResponse> Select(Guid coupleId, Guid activityId, UpdateSelectionRequest request);
    Task<ActivityResponse> Complete(Guid coupleId, Guid activityId);
    Task<ActivityResponse> Restore(Guid coupleId, Guid activityId);
    Task Delete(Guid coupleId, Guid activityId);
    Task<ActivityResponse> Spin(Guid coupleId, SpinRequest request);
}

public class ActivityService(DatingPickDbContext db) : IActivityService {
    public async Task<List<ActivityResponse>> List(Guid id) =>
        (await db.Activities.Include(x=>x.Selections)
        .Where(x=>x.CoupleId==id && x.Status!="Deleted")
        .OrderBy(x=>x.Status=="Completed").ThenByDescending(x=>x.CreatedAtUtc)
        .ToListAsync()).Select(Map).ToList();

    public async Task<ActivityResponse> Create(Guid id, CreateActivityRequest r) {
        if (string.IsNullOrWhiteSpace(r.ActivityText)) throw new ArgumentException("活動內容不可為空");
        var a=new Activity { ActivityId=Guid.NewGuid(), CoupleId=id, OwnerMemberId=r.OwnerMemberId,
            ActivityText=r.ActivityText.Trim(), Status="Active", CreatedAtUtc=DateTime.UtcNow };
        db.Activities.Add(a);
        var members=await db.CoupleMembers.Where(x=>x.CoupleId==id).ToListAsync();
        foreach(var m in members) db.ActivitySelections.Add(new ActivitySelection{
            ActivityId=a.ActivityId,MemberId=m.MemberId,IsSelected=false,UpdatedAtUtc=DateTime.UtcNow});
        await db.SaveChangesAsync(); await Load(a); return Map(a);
    }

    public async Task<ActivityResponse> Select(Guid id, Guid aid, UpdateSelectionRequest r) {
        var a=await Find(id,aid);
        var s=await db.ActivitySelections.FirstOrDefaultAsync(x=>x.ActivityId==aid&&x.MemberId==r.MemberId);
        if(s==null){s=new ActivitySelection{ActivityId=aid,MemberId=r.MemberId};db.ActivitySelections.Add(s);}
        s.IsSelected=r.IsSelected;s.UpdatedAtUtc=DateTime.UtcNow;
        await db.SaveChangesAsync();await Load(a);return Map(a);
    }

    public async Task<ActivityResponse> Complete(Guid id, Guid aid) {
        var a=await Find(id,aid);a.Status="Completed";a.CompletedAtUtc=DateTime.UtcNow;
        await db.SaveChangesAsync();return Map(a);
    }

    public async Task<ActivityResponse> Restore(Guid id, Guid aid) {
        var a=await Find(id,aid);a.Status="Active";a.CompletedAtUtc=null;
        await db.SaveChangesAsync();return Map(a);
    }

    public async Task Delete(Guid id, Guid aid) {
        var a=await Find(id,aid);a.Status="Deleted";a.DeletedAtUtc=DateTime.UtcNow;
        db.ActivitySelections.RemoveRange(await db.ActivitySelections.Where(x=>x.ActivityId==aid).ToListAsync());
        await db.SaveChangesAsync();
    }

    public async Task<ActivityResponse> Spin(Guid id, SpinRequest r) {
        var q=db.Activities.Include(x=>x.Selections).Where(x=>x.CoupleId==id&&x.Status=="Active");
        if(r.Mode=="common"){
            var n=await db.CoupleMembers.CountAsync(x=>x.CoupleId==id);
            q=q.Where(x=>x.Selections.Count(s=>s.IsSelected)==n);
        } else if(r.Mode=="member"&&r.MemberId.HasValue)
            q=q.Where(x=>x.Selections.Any(s=>s.MemberId==r.MemberId&&s.IsSelected));
        var list=await q.ToListAsync();
        if(list.Count==0)throw new InvalidOperationException("沒有符合條件的活動");
        var a=list[Random.Shared.Next(list.Count)];
        db.SpinHistories.Add(new SpinHistory{SpinHistoryId=Guid.NewGuid(),CoupleId=id,MemberId=r.MemberId,ActivityId=a.ActivityId,Mode=r.Mode,CreatedAtUtc=DateTime.UtcNow});
        await db.SaveChangesAsync();return Map(a);
    }

    async Task<Activity> Find(Guid id,Guid aid)=>await db.Activities.Include(x=>x.Selections)
        .FirstOrDefaultAsync(x=>x.CoupleId==id&&x.ActivityId==aid&&x.Status!="Deleted")
        ?? throw new KeyNotFoundException("找不到活動");
    Task Load(Activity a)=>db.Entry(a).Collection(x=>x.Selections).LoadAsync();
    static ActivityResponse Map(Activity a)=>new(){ActivityId=a.ActivityId,CoupleId=a.CoupleId,OwnerMemberId=a.OwnerMemberId,ActivityText=a.ActivityText,Status=a.Status,CreatedAtUtc=a.CreatedAtUtc,CompletedAtUtc=a.CompletedAtUtc,Selections=a.Selections.Select(s=>new SelectionResponse{MemberId=s.MemberId,IsSelected=s.IsSelected}).ToList()};
}
