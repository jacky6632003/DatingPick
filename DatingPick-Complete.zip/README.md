# DatingPick-Complete

Vue 3 + ASP.NET Core 8 + EF Core 8 + SQL Server。

前端 `Frontend/index.html` 支援 **API / LocalStorage 開關**，同一套 UI 可離線測試或連線後端。保留雙方意願、共同活動、完成/還原、刪除與 Roulette 抽選動畫。

Demo Couple：11111111-1111-1111-1111-111111111111
Jacky：22222222-2222-2222-2222-222222222222
紫紫：33333333-3333-3333-3333-333333333333

## API
修改 `Frontend/index.html` 的 APP_CONFIG：
`dataMode: 'local'` 或 `'api'`，以及 `apiBaseUrl`。

## SQL
依序執行 `Database/01_CreateDatingPick.sql`，再依需求填入資料。
