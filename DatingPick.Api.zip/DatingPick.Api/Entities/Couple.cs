namespace DatingPick.Api.Entities;
public class Couple {
    public Guid CoupleId { get; set; }
    public string? InviteCode { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public bool IsActive { get; set; }
    public ICollection<CoupleMember> Members { get; set; } = new List<CoupleMember>();
}