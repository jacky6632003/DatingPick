namespace DatingPick.Api.Entities;
public class ActivitySelection {
    public Guid ActivityId { get; set; }
    public Guid MemberId { get; set; }
    public bool IsSelected { get; set; }
    public DateTime UpdatedAt { get; set; }
}