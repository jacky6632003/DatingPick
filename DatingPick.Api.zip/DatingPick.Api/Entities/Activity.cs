namespace DatingPick.Api.Entities;
public class Activity {
    public Guid ActivityId { get; set; }
    public Guid CoupleId { get; set; }
    public Guid OwnerMemberId { get; set; }
    public string ActivityText { get; set; } = "";
    public string Status { get; set; } = "Active";
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public DateTime? DeletedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public byte[]? RowVersion { get; set; }
}