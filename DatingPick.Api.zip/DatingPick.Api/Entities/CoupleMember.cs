namespace DatingPick.Api.Entities;
public class CoupleMember {
    public Guid MemberId { get; set; }
    public Guid CoupleId { get; set; }
    public string Role { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string? Icon { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsActive { get; set; }
    public Couple Couple { get; set; } = null!;
}