namespace DatingPick.Api.Entities;
public class SpinHistory {
    public Guid SpinId { get; set; }
    public Guid CoupleId { get; set; }
    public string Mode { get; set; } = "";
    public Guid? ActivityId { get; set; }
    public string? ActivityText { get; set; }
    public DateTime CreatedAt { get; set; }
}