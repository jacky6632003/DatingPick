using DatingPick.Api.Data;
using DatingPick.Api.DTOs;
using DatingPick.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace DatingPick.Api.Services;

public interface IActivityService
{
    Task<List<ActivityResponse>> GetAsync(Guid coupleId, string status);
    Task<ActivityResponse> CreateAsync(Guid coupleId, CreateActivityRequest request);
    Task CompleteAsync(Guid coupleId, Guid activityId);
    Task RestoreAsync(Guid coupleId, Guid activityId);
    Task DeleteAsync(Guid coupleId, Guid activityId);
    Task ToggleSelectionAsync(Guid coupleId, Guid memberId, Guid activityId, bool selected);
    Task<List<ActivityResponse>> GetCommonAsync(Guid coupleId);
    Task<ActivityResponse?> SpinAsync(Guid coupleId, string mode);
}

public class ActivityService : IActivityService
{
    private readonly DatingPickDbContext _db;
    public ActivityService(DatingPickDbContext db) => _db = db;

    private async Task<Activity?> Find(Guid coupleId, Guid activityId) =>
        await _db.Activities.FirstOrDefaultAsync(x => x.CoupleId == coupleId && x.ActivityId == activityId);

    public async Task<List<ActivityResponse>> GetAsync(Guid coupleId, string status)
    {
        var query = _db.Activities.AsNoTracking()
            .Where(x => x.CoupleId == coupleId && x.Status == status);
        return await ToResponse(query);
    }

    private async Task<List<ActivityResponse>> ToResponse(IQueryable<Activity> query)
    {
        var activities = await query.OrderBy(x => x.CreatedAt).ToListAsync();
        var ids = activities.Select(x => x.ActivityId).ToList();
        var selections = await _db.ActivitySelections.AsNoTracking()
            .Where(x => ids.Contains(x.ActivityId)).ToListAsync();

        return activities.Select(a => new ActivityResponse(
            a.ActivityId, a.OwnerMemberId, a.ActivityText, a.Status,
            a.CreatedAt, a.CompletedAt,
            selections.Where(s => s.ActivityId == a.ActivityId)
                .Select(s => new SelectionResponse(s.MemberId, s.IsSelected))
        )).ToList();
    }

    public async Task<ActivityResponse> CreateAsync(Guid coupleId, CreateActivityRequest request)
    {
        var memberOk = await _db.CoupleMembers.AnyAsync(x =>
            x.CoupleId == coupleId && x.MemberId == request.OwnerMemberId && x.IsActive);
        if (!memberOk) throw new ArgumentException("OwnerMemberId 不屬於此 Couple。");

        var text = request.ActivityText.Trim();
        if (string.IsNullOrWhiteSpace(text) || text.Length > 100)
            throw new ArgumentException("活動名稱不可為空且不可超過 100 字。");

        var exists = await _db.Activities.AnyAsync(x =>
            x.CoupleId == coupleId && x.Status != "Deleted" && x.ActivityText == text);
        if (exists) throw new InvalidOperationException("活動已存在。");

        var entity = new Activity {
            CoupleId = coupleId, OwnerMemberId = request.OwnerMemberId,
            ActivityText = text, Status = "Active",
            CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
        };
        _db.Activities.Add(entity);
        await _db.SaveChangesAsync();
        return (await GetAsync(coupleId, "Active")).Single(x => x.ActivityId == entity.ActivityId);
    }

    public async Task CompleteAsync(Guid coupleId, Guid activityId)
    {
        await using var tx = await _db.Database.BeginTransactionAsync();
        var a = await Find(coupleId, activityId) ?? throw new KeyNotFoundException("找不到活動。");
        if (a.Status != "Active") throw new InvalidOperationException("只有進行中的活動可以完成。");
        a.Status = "Completed"; a.CompletedAt = DateTime.UtcNow; a.UpdatedAt = DateTime.UtcNow;
        var selections = await _db.ActivitySelections.Where(x => x.ActivityId == activityId).ToListAsync();
        _db.ActivitySelections.RemoveRange(selections);
        await _db.SaveChangesAsync();
        await tx.CommitAsync();
    }

    public async Task RestoreAsync(Guid coupleId, Guid activityId)
    {
        var a = await Find(coupleId, activityId) ?? throw new KeyNotFoundException("找不到活動。");
        if (a.Status != "Completed") throw new InvalidOperationException("只有已完成的活動可以還原。");
        a.Status = "Active"; a.CompletedAt = null; a.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
    }

    public async Task DeleteAsync(Guid coupleId, Guid activityId)
    {
        var a = await Find(coupleId, activityId) ?? throw new KeyNotFoundException("找不到活動。");
        a.Status = "Deleted"; a.DeletedAt = DateTime.UtcNow; a.UpdatedAt = DateTime.UtcNow;
        var selections = await _db.ActivitySelections.Where(x => x.ActivityId == activityId).ToListAsync();
        _db.ActivitySelections.RemoveRange(selections);
        await _db.SaveChangesAsync();
    }

    public async Task ToggleSelectionAsync(Guid coupleId, Guid memberId, Guid activityId, bool selected)
    {
        var valid = await _db.CoupleMembers.AnyAsync(x => x.CoupleId == coupleId && x.MemberId == memberId && x.IsActive);
        if (!valid) throw new ArgumentException("MemberId 不屬於此 Couple。");
        var a = await Find(coupleId, activityId) ?? throw new KeyNotFoundException("找不到活動。");
        if (a.Status != "Active") throw new InvalidOperationException("只有進行中的活動可以選擇。");

        var row = await _db.ActivitySelections.FindAsync(activityId, memberId);
        if (selected) {
            if (row == null) _db.ActivitySelections.Add(new ActivitySelection {
                ActivityId = activityId, MemberId = memberId, IsSelected = true, UpdatedAt = DateTime.UtcNow
            });
            else { row.IsSelected = true; row.UpdatedAt = DateTime.UtcNow; }
        } else if (row != null) _db.ActivitySelections.Remove(row);

        await _db.SaveChangesAsync();
    }

    public async Task<List<ActivityResponse>> GetCommonAsync(Guid coupleId)
    {
        var memberIds = await _db.CoupleMembers.Where(x => x.CoupleId == coupleId && x.IsActive)
            .Select(x => x.MemberId).ToListAsync();
        if (memberIds.Count < 2) return new();
        var query = _db.Activities.Where(a => a.CoupleId == coupleId && a.Status == "Active")
            .Where(a => _db.ActivitySelections.Count(s => s.ActivityId == a.ActivityId && s.IsSelected && memberIds.Contains(s.MemberId)) == memberIds.Count);
        return await ToResponse(query);
    }

    public async Task<ActivityResponse?> SpinAsync(Guid coupleId, string mode)
    {
        IQueryable<Activity> query = _db.Activities.Where(x => x.CoupleId == coupleId && x.Status == "Active");
        if (mode.Equals("Common", StringComparison.OrdinalIgnoreCase))
            return (await GetCommonAsync(coupleId)).OrderBy(_ => Guid.NewGuid()).FirstOrDefault();

        if (mode.Equals("Male", StringComparison.OrdinalIgnoreCase) ||
            mode.Equals("Female", StringComparison.OrdinalIgnoreCase))
        {
            var member = await _db.CoupleMembers.FirstOrDefaultAsync(x =>
                x.CoupleId == coupleId && x.Role == mode.ToLower());
            if (member == null) return null;
            query = query.Where(x => x.OwnerMemberId == member.MemberId);
            var list = await ToResponse(query);
            return list.OrderBy(_ => Guid.NewGuid()).FirstOrDefault();
        }

        var item = await query.OrderBy(_ => Guid.NewGuid()).FirstOrDefaultAsync();
        if (item == null) return null;
        return (await ToResponse(query.Where(x => x.ActivityId == item.ActivityId))).Single();
    }
}
