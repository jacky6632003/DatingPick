using DatingPick.Api.DTOs;
using DatingPick.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DatingPick.Api.Controllers;

[ApiController]
[Route("api/v1/couples/{coupleId:guid}/activities")]
public class ActivitiesController : ControllerBase
{
    private readonly IActivityService _service;
    public ActivitiesController(IActivityService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> Get(Guid coupleId, [FromQuery] string status = "Active") =>
        Ok(new { success = true, data = await _service.GetAsync(coupleId, status) });

    [HttpPost]
    public async Task<IActionResult> Create(Guid coupleId, CreateActivityRequest request) =>
        Ok(new { success = true, data = await _service.CreateAsync(coupleId, request) });

    [HttpPost("{activityId:guid}/complete")]
    public async Task<IActionResult> Complete(Guid coupleId, Guid activityId) {
        await _service.CompleteAsync(coupleId, activityId);
        return Ok(new { success = true });
    }

    [HttpPost("{activityId:guid}/restore")]
    public async Task<IActionResult> Restore(Guid coupleId, Guid activityId) {
        await _service.RestoreAsync(coupleId, activityId);
        return Ok(new { success = true });
    }

    [HttpDelete("{activityId:guid}")]
    public async Task<IActionResult> Delete(Guid coupleId, Guid activityId) {
        await _service.DeleteAsync(coupleId, activityId);
        return Ok(new { success = true });
    }

    [HttpPut("{activityId:guid}/selection/{memberId:guid}")]
    public async Task<IActionResult> Selection(Guid coupleId, Guid activityId, Guid memberId, UpdateSelectionRequest request) {
        await _service.ToggleSelectionAsync(coupleId, memberId, activityId, request.IsSelected);
        return Ok(new { success = true });
    }
}

[ApiController]
[Route("api/v1/couples/{coupleId:guid}")]
public class CoupleActivitiesController : ControllerBase
{
    private readonly IActivityService _service;
    public CoupleActivitiesController(IActivityService service) => _service = service;

    [HttpGet("common-activities")]
    public async Task<IActionResult> Common(Guid coupleId) =>
        Ok(new { success = true, data = await _service.GetCommonAsync(coupleId) });

    [HttpPost("spin")]
    public async Task<IActionResult> Spin(Guid coupleId, SpinRequest request) {
        var result = await _service.SpinAsync(coupleId, request.Mode);
        return Ok(new { success = true, data = result });
    }
}
