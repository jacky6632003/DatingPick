using DatingPick.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace DatingPick.Api.Data;

public class DatingPickDbContext : DbContext
{
    public DatingPickDbContext(DbContextOptions<DatingPickDbContext> options) : base(options) { }

    public DbSet<Couple> Couples => Set<Couple>();
    public DbSet<CoupleMember> CoupleMembers => Set<CoupleMember>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<ActivitySelection> ActivitySelections => Set<ActivitySelection>();
    public DbSet<SpinHistory> SpinHistories => Set<SpinHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Couple>(e => {
            e.HasKey(x => x.CoupleId);
            e.Property(x => x.InviteCode).HasMaxLength(20).IsUnicode(false);
            e.HasMany(x => x.Members).WithOne(x => x.Couple).HasForeignKey(x => x.CoupleId);
        });
        modelBuilder.Entity<CoupleMember>(e => {
            e.HasKey(x => x.MemberId);
            e.Property(x => x.Role).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.DisplayName).HasMaxLength(50);
            e.Property(x => x.Icon).HasMaxLength(10);
            e.HasIndex(x => new { x.CoupleId, x.Role }).IsUnique();
        });
        modelBuilder.Entity<Activity>(e => {
            e.HasKey(x => x.ActivityId);
            e.Property(x => x.ActivityText).HasMaxLength(100);
            e.Property(x => x.Status).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.RowVersion).IsRowVersion();
            e.HasIndex(x => new { x.CoupleId, x.Status });
        });
        modelBuilder.Entity<ActivitySelection>(e => {
            e.HasKey(x => new { x.ActivityId, x.MemberId });
        });
        modelBuilder.Entity<SpinHistory>(e => {
            e.HasKey(x => x.SpinId);
            e.Property(x => x.Mode).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.ActivityText).HasMaxLength(100);
        });
    }
}
