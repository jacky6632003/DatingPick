namespace DatingPick.Api.DTOs;
public record ActivityResponse(
    Guid ActivityId,
    Guid OwnerMemberId,
    string ActivityText,
    string Status,
    DateTime CreatedAt,
    DateTime? CompletedAt,
    IEnumerable<SelectionResponse> Selections
);
public record SelectionResponse(Guid MemberId, bool IsSelected);