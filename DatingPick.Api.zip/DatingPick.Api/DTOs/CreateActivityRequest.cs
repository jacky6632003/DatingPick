namespace DatingPick.Api.DTOs;
public record CreateActivityRequest(Guid OwnerMemberId, string ActivityText);