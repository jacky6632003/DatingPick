namespace DatingPick.Api.DTOs;
public record UpdateSelectionRequest(bool IsSelected);