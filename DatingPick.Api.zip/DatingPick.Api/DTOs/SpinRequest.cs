namespace DatingPick.Api.DTOs;
public record SpinRequest(string Mode);