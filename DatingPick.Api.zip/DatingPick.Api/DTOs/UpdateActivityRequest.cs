namespace DatingPick.Api.DTOs;
public record UpdateActivityRequest(string ActivityText);