# Projects and dependencies analysis

This document provides a comprehensive overview of the projects and their dependencies in the context of upgrading to .NETCoreApp,Version=v10.0.

## Table of Contents

- [Executive Summary](#executive-Summary)
  - [Highlevel Metrics](#highlevel-metrics)
  - [Projects Compatibility](#projects-compatibility)
  - [Package Compatibility](#package-compatibility)
  - [API Compatibility](#api-compatibility)
  - [Binding Redirect Configuration](#binding-redirect-configuration)
- [Aggregate NuGet packages details](#aggregate-nuget-packages-details)
- [Top API Migration Challenges](#top-api-migration-challenges)
  - [Technologies and Features](#technologies-and-features)
  - [Most Frequent API Issues](#most-frequent-api-issues)
- [Projects Relationship Graph](#projects-relationship-graph)
- [Project Details](#project-details)

  - [DatingPick.Api.csproj](#datingpickapicsproj)


## Executive Summary

### Highlevel Metrics

| Metric | Count | Status |
| :--- | :---: | :--- |
| Total Projects | 1 | All require upgrade |
| Total NuGet Packages | 102 | 2 need upgrade |
| Total Code Files | 15 |  |
| Total Code Files with Incidents | 1 |  |
| Total Lines of Code | 360 |  |
| Total Number of Issues | 5 |  |
| Estimated LOC to modify | 0+ | at least 0.0% of codebase |

### Projects Compatibility

| Project | Target Framework | Difficulty | Package Issues | API Issues | Binding Issues | Est. LOC Impact | Description |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| [DatingPick.Api.csproj](#datingpickapicsproj) | net6.0 | 🟢 Low | 4 | 0 | 0 |  | AspNetCore, Sdk Style = True |

### Package Compatibility

| Status | Count | Percentage |
| :--- | :---: | :---: |
| ✅ Compatible | 100 | 98.0% |
| ⚠️ Incompatible | 0 | 0.0% |
| 🔄 Upgrade Recommended | 2 | 2.0% |
| ***Total NuGet Packages*** | ***102*** | ***100%*** |

### API Compatibility

| Category | Count | Impact |
| :--- | :---: | :--- |
| 🔴 Binary Incompatible | 0 | High - Require code changes |
| 🟡 Source Incompatible | 0 | Medium - Needs re-compilation and potential conflicting API error fixing |
| 🔵 Behavioral change | 0 | Low - Behavioral changes that may require testing at runtime |
| ✅ Compatible | 998 |  |
| ***Total APIs Analyzed*** | ***998*** |  |

## Aggregate NuGet packages details

| Package | Current Version | Suggested Version | Projects | Description |
| :--- | :---: | :---: | :--- | :--- |
| Humanizer.Core | 2.8.26 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.CSharp | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Data.SqlClient | 2.0.1 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Data.SqlClient.SNI.runtime | 2.0.1 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.EntityFrameworkCore | 5.0.17 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.EntityFrameworkCore.Abstractions | 5.0.17 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.EntityFrameworkCore.Analyzers | 5.0.17 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.EntityFrameworkCore.Design | 5.0.17 | 10.0.12 | [DatingPick.Api.csproj](#datingpickapicsproj) | 建議升級 NuGet 套件 |
| Microsoft.EntityFrameworkCore.Relational | 5.0.17 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.EntityFrameworkCore.SqlServer | 5.0.17 | 10.0.12 | [DatingPick.Api.csproj](#datingpickapicsproj) | 建議升級 NuGet 套件 |
| Microsoft.Extensions.ApiDescription.Server | 3.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Caching.Abstractions | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Caching.Memory | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Configuration.Abstractions | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.DependencyInjection | 5.0.2 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.DependencyInjection.Abstractions | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Logging | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Logging.Abstractions | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Options | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Extensions.Primitives | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Identity.Client | 4.14.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.IdentityModel.JsonWebTokens | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.IdentityModel.Logging | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.IdentityModel.Protocols | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.IdentityModel.Protocols.OpenIdConnect | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.IdentityModel.Tokens | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.NETCore.Platforms | 3.1.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.NETCore.Targets | 1.1.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.OpenApi | 1.2.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Win32.Registry | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Microsoft.Win32.SystemEvents | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Newtonsoft.Json | 10.0.1 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| runtime.native.System | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Swashbuckle.AspNetCore | 5.6.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Swashbuckle.AspNetCore.Swagger | 5.6.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Swashbuckle.AspNetCore.SwaggerGen | 5.6.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| Swashbuckle.AspNetCore.SwaggerUI | 5.6.3 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Collections | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Collections.Concurrent | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Collections.Immutable | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Collections.NonGeneric | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Collections.Specialized | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.ComponentModel | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.ComponentModel.Annotations | 5.0.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.ComponentModel.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.ComponentModel.TypeConverter | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Configuration.ConfigurationManager | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Diagnostics.Debug | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Diagnostics.DiagnosticSource | 5.0.1 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Diagnostics.Tools | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Diagnostics.Tracing | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Drawing.Common | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Dynamic.Runtime | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Globalization | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Globalization.Extensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.IdentityModel.Tokens.Jwt | 5.6.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.IO | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.IO.FileSystem | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.IO.FileSystem.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Linq | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Linq.Expressions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Net.NameResolution | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Net.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.ObjectModel | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Private.DataContractSerialization | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Private.Uri | 4.3.2 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.Emit | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.Emit.ILGeneration | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.Emit.Lightweight | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.Extensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Reflection.TypeExtensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Resources.ResourceManager | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Caching | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Extensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Handles | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.InteropServices | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Numerics | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Serialization.Formatters | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Serialization.Json | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Runtime.Serialization.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.AccessControl | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.Cryptography.Cng | 4.5.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.Cryptography.Primitives | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.Cryptography.ProtectedData | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.Permissions | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.Principal.Windows | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Security.SecureString | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Text.Encoding | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Text.Encoding.CodePages | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Text.Encoding.Extensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Text.RegularExpressions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Threading | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Threading.Tasks | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Threading.Tasks.Extensions | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Windows.Extensions | 4.7.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Xml.ReaderWriter | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Xml.XDocument | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Xml.XmlDocument | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |
| System.Xml.XmlSerializer | 4.3.0 |  | [DatingPick.Api.csproj](#datingpickapicsproj) | ✅Compatible |

## Top API Migration Challenges

### Technologies and Features

| Technology | Issues | Percentage | Migration Path |
| :--- | :---: | :---: | :--- |

### Most Frequent API Issues

| API | Count | Percentage | Category |
| :--- | :---: | :---: | :--- |

## Projects Relationship Graph

Legend:
📦 SDK-style project
⚙️ Classic project

```mermaid
flowchart LR
    P1["<b>📦&nbsp;DatingPick.Api.csproj</b><br/><small>net6.0</small>"]
    click P1 "#datingpickapicsproj"

```

## Project Details

<a id="datingpickapicsproj"></a>
### DatingPick.Api.csproj

#### Project Info

- **Current Target Framework:** net6.0
- **Proposed Target Framework:** net10.0
- **SDK-style**: True
- **Project Kind:** AspNetCore
- **Dependencies**: 0
- **Dependants**: 0
- **Number of Files**: 16
- **Number of Files with Incidents**: 1
- **Lines of Code**: 360
- **Estimated LOC to modify**: 0+ (at least 0.0% of the project)

#### Dependency Graph

Legend:
📦 SDK-style project
⚙️ Classic project

```mermaid
flowchart TB
    subgraph current["DatingPick.Api.csproj"]
        MAIN["<b>📦&nbsp;DatingPick.Api.csproj</b><br/><small>net6.0</small>"]
        click MAIN "#datingpickapicsproj"
    end

```

### API Compatibility

| Category | Count | Impact |
| :--- | :---: | :--- |
| 🔴 Binary Incompatible | 0 | High - Require code changes |
| 🟡 Source Incompatible | 0 | Medium - Needs re-compilation and potential conflicting API error fixing |
| 🔵 Behavioral change | 0 | Low - Behavioral changes that may require testing at runtime |
| ✅ Compatible | 998 |  |
| ***Total APIs Analyzed*** | ***998*** |  |

